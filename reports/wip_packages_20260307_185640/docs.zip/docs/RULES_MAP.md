# Сводка правил (Rules Map)

## Тезис
В workspace integrator правила существуют на нескольких уровнях (пользовательские, проектные, репозиторные и проект-специфичные). Эта сводка фиксирует приоритет и минимальный набор обязательных требований к документации и процессу.

## Антитезис (риски)
- Правила распределены по файлам и легко “расходятся” (дрейф).
- Одно и то же требование может быть сформулировано по‑разному в разных проектах.
- Документация и артефакты могут смешиваться с секретами или временными логами, если нет явного протокола.

## Синтез (приоритет и применение)

### Приоритет правил (от более высокого к более низкому)
1) `.trae/rules/user_rules.md` — язык, формат ответа, docs-first, безопасность, верификация.
2) `.trae/rules/project_rules.md` — проектные дефолты, протокол верификации, “Session End”.
3) `docs/PROJECT_RULES_FULL.md` — полная спецификация и обязательные разделы (включая “Заповедник промптов”).
4) `AGENTS.md` — операционные дефолты для агента в этом репозитории (preflight/quality gates/семантика).
5) Проект-специфичные правила в подпроектах (`C:\LocalAI\assistant`, `vault/Projects/*`) — действуют внутри соответствующего проекта и не должны противоречить 1–3.

### Обязательства к документации (канон)
- **Docs-first**: для нетривиальных изменений сначала план/spec, затем выполнение, затем итоговая документация (README/отчёт/инструкции).
- **T+A=S**: для любых изменений и решений фиксировать Тезис → Антитезис → Синтез и “Next atomic step” (один).
- **Evidence-based**: “работает” означает “проверено” (тест/команда/лог). Если не проверено — явно помечать.
- **No secrets**: токены/пароли/ключи не пишутся в документы/логи/PR/issue. Разрешено только “present/len”.
- **Один артефакт на сложную задачу**: длинные логи не вставлять в чат; сохранять в файл в `docs/` или `reports/` и ссылаться.

### Где что лежит (источники правил)
- Workspace:
  - `.trae/rules/project_rules.md`
  - `.trae/rules/user_rules.md`
  - `AGENTS.md`
  - `.github/PROJECT_CANON.md` (GitHub-канон: issue/project/workflow)
  - `docs/PROJECT_RULES_FULL.md`
- LocalAI assistant:
  - `C:\LocalAI\assistant\.trae\rules\*`
- Vault проекты (выборочно):
  - `vault/Projects/AlgoTrading/.trae/rules/project_rules.md`
  - `vault/Projects/Claude Stealth Connect/.trae/rules/*`
  - `vault/Projects/vpn-manager/.trae/rules/*`, `SECURITY.md`, `CONTRIBUTING.md`

### Зафиксированная операционная рекомендация
- Основной рабочий цикл сессии: `workflow zapovednik append` без `--path` (append-first).
- После `workflow zapovednik finalize` следующий `append` без `--path` автоматически создаёт новую сессию.
- `workflow zapovednik health --json` использовать как machine-checkable источник `recommend_close`.
- `workflow zapovednik append --auto-finalize-on-threshold --json` использовать для авто-закрытия перед append по порогам.
- `python -m integrator session open --json` использовать как fallback для ручного принудительного старта.
- Для fallback-старта использовать JSON-контракт `success`, `path`, `path_masked`.
- Табличный вывод не использовать как источник машинной валидации.
- Закрытие сессии выполнять через `python -m integrator session close --json`.

## Next atomic step
Поддерживать “Заповедник промптов” и “Самоанализ” как обязательные артефакты сессий: дополнять, но не раскрывать секреты.
